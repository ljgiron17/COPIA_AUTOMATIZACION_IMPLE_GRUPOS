package inventory;
//Alumna: YEYMI DARIELA AGUILAR 0801-1998-12961
import java.util.Scanner;

public class ProductTester {

	static int items = 6;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Proyecto 5
		 */
		Scanner in = new Scanner(System.in);
		
		int tempNum;
		String tempNombre;
		int tempCantidad;
		double tempPrecio;
		
		System.out.println("Product 1");
		System.out.println("Escriba el n�mero de producto:");
		tempNum = in.nextInt();
		System.out.println("Escriba el nombre de producto:");
		tempNombre = in.next();
		System.out.println("Escriba la Cantidad de producto:");
		tempCantidad = in.nextInt();
		System.out.println("Escriba el precio de producto:");
		tempPrecio = in.nextDouble();
		
		product p1 = new product(tempNum, tempNombre, tempCantidad, tempPrecio);
		
		in.nextLine();

		System.out.println("Product 2");
		System.out.println("Escriba el n�mero de producto:");
		tempNum = in.nextInt();
		System.out.println("Escriba el nombre de producto:");
		tempNombre = in.next();
		System.out.println("Escriba la cantidad de producto:");
		tempCantidad = in.nextInt();
		System.out.println("Escriba el precio de producto:");
		tempPrecio = in.nextDouble();
		
		product p2 = new product(tempNum, tempNombre, tempCantidad, tempPrecio);
		
		in.close();
		
		
		/*
		 * Fin Proyecto 5
		 */
		
		/*
		 * Proyecto 4
		 */
		//4 productos creados con constructor con par�metros
		product prodMouse = new product(1, "Mouse", 100, 200.0);
		product prodKeyboard = new product(2, "Keyboard", 80, 299.50);
		product prodMonitor = new product(3, "Monitor", 20, 2000.0);
		product prodPrinter = new product(4, "Printer", 50, 1500.0);
		
		//2 productos creados con constructor predeterminado
		product prodFlashDrive = new product();
		prodFlashDrive.setNumproduct(5);
		prodFlashDrive.setNombreproduct("Flash drive");
		prodFlashDrive.setCantproduct(200);
		prodFlashDrive.setprecioproduct(200.0);
		
		product prodSpeakers = new product();
		prodSpeakers.setNumproduct(6);
		prodSpeakers.setNombreproduct("Speakers");
		prodSpeakers.setCantproduct(40);
		prodSpeakers.setprecioproduct(495.50);
		
		prodSpeakers.setActivosproduct(false);
		
		//Visualizar los detalles de cada producto		
		System.out.println("Inventario");
		System.out.println("------------------------------");
		
		System.out.println("Entrada de usuario");
		
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
		System.out.println("------------------------------");
		
		System.out.println(prodMouse.toString());
		System.out.println(prodKeyboard.toString());
		System.out.println(prodMonitor.toString());
		System.out.println(prodPrinter.toString());
		System.out.println(prodSpeakers.toString());
		System.out.println(prodFlashDrive.toString());
		
		/*
		 * Fin Proyecto 4
		 */
	}

}
