package inventory;
//Alumna: YEYMI DARIELA AGUILAR 0801-1998-12961


public class product {
	//atributos
	private String Nombreproduct;
	private int Numproduct;
	private int Cantproduct;
	private double precioproduct;
	private boolean Activosproduct = true;
	
//Constructor predeterminado que permitir� que el compilador inicialice  en sus valores anteriores
public product() {
	
}
public product (int Numproduct, String Nombreproduct, int Cantproduct, double precioproduct) {
	super();
	this.Numproduct = Numproduct;
	this.Nombreproduct = Nombreproduct;
	this.Cantproduct = Cantproduct;
	this.precioproduct = precioproduct;
}


public String toString() {
	String productDescription = "";
	
	productDescription += "N�mero                : " + this.getNumproduct() + "\n";
	productDescription += "Nombre                : " + this.getNombreproduct() + "\n";
	productDescription += "Cantidad en iventario : " + this.getCantproduct() + "\n";
	productDescription += "Precio                : " + this.getprecioproduct() + "\n";
	productDescription += "Valor de inventario   : " + this.getvalorInv() + "\n";
	productDescription += "Estado de producto    : " + ((this.isActivosproduct()) ? "Activo" : "Descatalogado") + "\n";
	
	return productDescription;
}


 //obtiene el valor del producto (precio por unidades en existencia)
 
private double getvalorInv() {
	return this.getprecioproduct() * this.getCantproduct();
}


//obtiene el n�mero de producto
 
public int getNumproduct() {
	return Numproduct;
}

//establece el n�mero de producto

public void setNumproduct(int Numproduct) {
	this.Numproduct = Numproduct;
}


//obtiene el nombre del producto

public String getNombreproduct() {
	return Nombreproduct;
}


//el nombre de producto

public void setNombreproduct(String Nombreproduct) {
	this.Nombreproduct = Nombreproduct;
}


//obtiene el valor de unidades en existencia del producto
 
public int getCantproduct() {
	return Cantproduct;
}

//El valor de unidades en existencia del producto 

public void setCantproduct(int Cantproduct) {
	this.Cantproduct = Cantproduct;
}


//obtener el precio del producto

public double getprecioproduct() {
	return precioproduct;
}

//precio del producto

public void setprecioproduct(double precioproduct) {
	this.precioproduct = precioproduct;
}

//Determina si el producto est� activo

public boolean isActivosproduct() {
	return Activosproduct;
}

//Valor de productos activos 

public void setActivosproduct(boolean Activosproduct) {
	this.Activosproduct = Activosproduct;
}
public void setNumProduct(int i) {
	// TODO Auto-generated method stub
	
}
}

